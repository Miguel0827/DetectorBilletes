import os
import shutil
from pathlib import Path
import random
from collections import defaultdict
import albumentations as A
import cv2
import numpy as np
from tqdm import tqdm
import gc

# Configuración
CLASES = ['100', '1000', '10000', '100000', '200', '2000', '20000', '50', '500', '5000', '50000']

# ESTRATEGIA DE BALANCEO INTELIGENTE
# Opción 1: TARGET FIJO - Intentar llegar a este número en todas las clases
IMAGENES_TARGET = 500
USAR_TARGET_FIJO = True  # ← CAMBIADO A TRUE PARA 500 POR CLASE

# Opción 2: BALANCEO PROPORCIONAL - Todas las clases tendrán el mismo número final
USAR_BALANCEO_PROPORCIONAL = False  # ← CAMBIADO A FALSE
MULTIPLICADOR_AUGMENTATION = 3  # Cada imagen original genera hasta 3 augmentadas

# Configuración de intentos
MAX_INTENTOS_POR_IMAGEN = 15  # Más intentos para clases pequeñas
TRAIN_SPLIT = 0.7  # 70% train
VALID_SPLIT = 0.2  # 20% valid
TEST_SPLIT = 0.1   # 10% test

# IMPORTANTE: Si quieres procesar TODAS las clases automáticamente (incluyendo "objeto" u otras)
# cambia esto a True. Si solo quieres las 11 clases de billetes, déjalo en False
PROCESAR_TODAS_LAS_CLASES = True  # Cambia a False si solo quieres los 11 billetes

# Rutas
BASE_DIR = Path(".")
TRAIN_IMAGES = BASE_DIR / "train" / "images"
TRAIN_LABELS = BASE_DIR / "train" / "labels"

# Crear estructura de carpetas de salida
OUTPUT_DIR = BASE_DIR / "dataset_balanceado"
for split in ['train', 'valid', 'test']:
    (OUTPUT_DIR / split / 'images').mkdir(parents=True, exist_ok=True)
    (OUTPUT_DIR / split / 'labels').mkdir(parents=True, exist_ok=True)

# Augmentations MÁS SUAVES para evitar que los bboxes se salgan
def crear_augmentations():
    """Crea diferentes pipelines de augmentation CONSERVADORES"""
    augs = [
        # Pipeline 1: Solo flip y ajustes de color (MUY SEGURO)
        A.Compose([
            A.HorizontalFlip(p=0.5),
            A.RandomBrightnessContrast(brightness_limit=0.15, contrast_limit=0.15, p=0.6),
        ], bbox_params=A.BboxParams(format='yolo', label_fields=['class_labels'], min_visibility=0.3)),
        
        # Pipeline 2: Rotación MÍNIMA + color
        A.Compose([
            A.Rotate(limit=5, p=0.5, border_mode=cv2.BORDER_CONSTANT),
            A.HueSaturationValue(hue_shift_limit=10, sat_shift_limit=15, val_shift_limit=10, p=0.4),
        ], bbox_params=A.BboxParams(format='yolo', label_fields=['class_labels'], min_visibility=0.4)),
        
        # Pipeline 3: Cambios de brillo/contraste fuertes pero SIN transformaciones geométricas
        A.Compose([
            A.RandomBrightnessContrast(brightness_limit=0.25, contrast_limit=0.25, p=0.7),
            A.RandomGamma(gamma_limit=(80, 120), p=0.3),
        ], bbox_params=A.BboxParams(format='yolo', label_fields=['class_labels'], min_visibility=0.3)),
        
        # Pipeline 4: Ruido y blur (no afecta posición)
        A.Compose([
            A.GaussNoise(var_limit=(10.0, 30.0), p=0.4),
            A.GaussianBlur(blur_limit=(3, 5), p=0.3),
        ], bbox_params=A.BboxParams(format='yolo', label_fields=['class_labels'], min_visibility=0.3)),
        
        # Pipeline 5: Shifts MUY PEQUEÑOS
        A.Compose([
            A.ShiftScaleRotate(
                shift_limit=0.05,
                scale_limit=0.05,
                rotate_limit=3,
                border_mode=cv2.BORDER_CONSTANT,
                p=0.5
            ),
        ], bbox_params=A.BboxParams(format='yolo', label_fields=['class_labels'], min_visibility=0.4)),
    ]
    return augs

def leer_label_yolo(label_path):
    """Lee las anotaciones YOLO del archivo y valida/corrige los bboxes"""
    if not label_path.exists():
        return [], []
    
    with open(label_path, 'r') as f:
        lines = f.readlines()
    
    bboxes = []
    class_labels = []
    for line in lines:
        parts = line.strip().split()
        if len(parts) >= 5:
            class_id = int(parts[0])
            x_c, y_c, w, h = [float(x) for x in parts[1:5]]
            
            # Validar y corregir bbox
            x_min = x_c - w/2
            y_min = y_c - h/2
            x_max = x_c + w/2
            y_max = y_c + h/2
            
            # Clip a rango válido [0, 1]
            x_min = max(0.0, min(1.0, x_min))
            y_min = max(0.0, min(1.0, y_min))
            x_max = max(0.0, min(1.0, x_max))
            y_max = max(0.0, min(1.0, y_max))
            
            # Recalcular centro y dimensiones
            new_w = x_max - x_min
            new_h = y_max - y_min
            new_x_c = x_min + new_w/2
            new_y_c = y_min + new_h/2
            
            # Solo agregar si el bbox tiene área válida
            if new_w > 0.01 and new_h > 0.01:
                bbox = [new_x_c, new_y_c, new_w, new_h]
                class_labels.append(class_id)
                bboxes.append(bbox)
    
    return bboxes, class_labels

def guardar_label_yolo(label_path, bboxes, class_labels):
    """Guarda las anotaciones en formato YOLO correctamente"""
    with open(label_path, 'w') as f:
        for class_id, bbox in zip(class_labels, bboxes):
            x_c, y_c, w, h = bbox
            
            # Asegurar que los valores están en rango [0, 1]
            x_c = max(0.0, min(1.0, x_c))
            y_c = max(0.0, min(1.0, y_c))
            w = max(0.0, min(1.0, w))
            h = max(0.0, min(1.0, h))
            
            # Formato YOLO: class_id x_center y_center width height
            f.write(f"{int(class_id)} {x_c:.6f} {y_c:.6f} {w:.6f} {h:.6f}\n")

def aplicar_augmentation(image_path, label_path, transform):
    """Aplica augmentation a una imagen y sus labels - OPTIMIZADO Y CORREGIDO"""
    try:
        image = cv2.imread(str(image_path))
        if image is None:
            return None, None, None
        
        # Si la imagen es muy grande, redimensionar temporalmente
        h, w = image.shape[:2]
        max_size = 1024
        if max(h, w) > max_size:
            scale = max_size / max(h, w)
            new_w = int(w * scale)
            new_h = int(h * scale)
            image = cv2.resize(image, (new_w, new_h))
        
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # Leer labels
        bboxes, class_labels = leer_label_yolo(label_path)
        
        if len(bboxes) == 0:
            return None, None, None
        
        # Validar que todos los bboxes estén en rango
        for bbox in bboxes:
            x_c, y_c, w, h = bbox
            if not (0 <= x_c <= 1 and 0 <= y_c <= 1 and 0 < w <= 1 and 0 < h <= 1):
                return None, None, None
        
        # Aplicar transformación
        transformed = transform(image=image, bboxes=bboxes, class_labels=class_labels)
        transformed_image = cv2.cvtColor(transformed['image'], cv2.COLOR_RGB2BGR)
        transformed_bboxes = transformed['bboxes']
        transformed_labels = transformed['class_labels']
        
        # Validar y corregir bboxes resultantes
        valid_boxes = []
        valid_labels = []
        
        for bbox, label in zip(transformed_bboxes, transformed_labels):
            x_c, y_c, w, h = bbox
            
            x_min = x_c - w/2
            y_min = y_c - h/2
            x_max = x_c + w/2
            y_max = y_c + h/2
            
            # VALIDACIÓN ESTRICTA
            if not (0 <= x_min < 1 and 0 <= y_min < 1 and 
                    0 < x_max <= 1 and 0 < y_max <= 1):
                continue
            
            if w < 0.02 or h < 0.02:
                continue
            
            if w > 0.95 or h > 0.95:
                continue
            
            if not (0.05 <= x_c <= 0.95 and 0.05 <= y_c <= 0.95):
                continue
            
            valid_boxes.append([x_c, y_c, w, h])
            valid_labels.append(label)
        
        if len(valid_boxes) == 0:
            return None, None, None
        
        if len(valid_boxes) < len(bboxes) * 0.5:
            return None, None, None
            
        return transformed_image, valid_boxes, valid_labels
        
    except Exception as e:
        return None, None, None
    finally:
        if 'image' in locals():
            del image
        if 'transformed' in locals():
            del transformed

def analizar_dataset():
    """Analiza cuántas imágenes hay por clase"""
    print("📊 Analizando dataset...")
    
    clase_a_imagenes = defaultdict(list)
    clases_encontradas = set()
    imagenes_con_problemas = 0
    
    extensiones = ['*.jpg', '*.jpeg', '*.png', '*.JPG', '*.JPEG', '*.PNG']
    todas_imagenes = []
    
    for ext in extensiones:
        todas_imagenes.extend(TRAIN_IMAGES.glob(ext))
    
    print(f"  🔍 Encontradas {len(todas_imagenes)} imágenes en total")
    
    for img_path in todas_imagenes:
        label_path = TRAIN_LABELS / f"{img_path.stem}.txt"
        
        if label_path.exists():
            bboxes, class_labels = leer_label_yolo(label_path)
            
            if len(bboxes) == 0:
                imagenes_con_problemas += 1
                continue
            
            for class_id in class_labels:
                clases_encontradas.add(class_id)
                clase_a_imagenes[class_id].append(img_path)
        else:
            imagenes_con_problemas += 1
    
    print(f"\n🎯 Clases detectadas en el dataset: {sorted(clases_encontradas)}")
    
    clases_no_definidas = clases_encontradas - set(range(len(CLASES)))
    if clases_no_definidas:
        print(f"\n⚠️  ATENCIÓN: Hay clases en tus labels que no están definidas:")
        for class_id in sorted(clases_no_definidas):
            print(f"     - Clase ID {class_id}: {len(set(clase_a_imagenes[class_id]))} imágenes")
        
        if not PROCESAR_TODAS_LAS_CLASES:
            print(f"\n💡 TIP: Estas clases NO se procesarán porque PROCESAR_TODAS_LAS_CLASES = False")
            clase_a_imagenes = {k: v for k, v in clase_a_imagenes.items() if k < len(CLASES)}
    
    print("\n📈 Distribución de imágenes por clase:")
    total_imagenes = 0
    for class_id in sorted(clase_a_imagenes.keys()):
        imagenes_unicas = len(set(clase_a_imagenes[class_id]))
        total_imagenes += imagenes_unicas
        
        if class_id < len(CLASES):
            nombre_clase = CLASES[class_id]
        else:
            nombre_clase = f"CLASE_DESCONOCIDA_{class_id}"
        
        print(f"  Clase {class_id} ({nombre_clase}): {imagenes_unicas} imágenes")
    
    if imagenes_con_problemas > 0:
        print(f"\n⚠️  Imágenes sin label o con bboxes inválidos: {imagenes_con_problemas}")
    print(f"📊 Total de imágenes válidas: {total_imagenes}")
    
    return clase_a_imagenes

def calcular_targets_balanceados(clase_a_imagenes):
    """Calcula el target óptimo para cada clase según la estrategia elegida"""
    
    if USAR_TARGET_FIJO:
        targets = {class_id: IMAGENES_TARGET for class_id in clase_a_imagenes.keys()}
        print(f"\n📊 Estrategia: TARGET FIJO = {IMAGENES_TARGET} imágenes por clase")
        
    elif USAR_BALANCEO_PROPORCIONAL:
        counts = {class_id: len(set(imgs)) for class_id, imgs in clase_a_imagenes.items()}
        max_count = max(counts.values())
        
        target_balanceado = max_count
        targets = {class_id: target_balanceado for class_id in clase_a_imagenes.keys()}
        
        print(f"\n📊 Estrategia: BALANCEO PROPORCIONAL")
        print(f"   Todas las clases tendrán: {target_balanceado} imágenes")
        print(f"   (Basado en la clase con más imágenes)")
    
    else:
        counts = {class_id: len(set(imgs)) for class_id, imgs in clase_a_imagenes.items()}
        targets = {
            class_id: count * MULTIPLICADOR_AUGMENTATION 
            for class_id, count in counts.items()
        }
        
        print(f"\n📊 Estrategia: MULTIPLICADOR x{MULTIPLICADOR_AUGMENTATION}")
        print(f"   Cada clase crecerá {MULTIPLICADOR_AUGMENTATION}x su tamaño original")
    
    print(f"\n📋 Plan de expansión por clase:")
    for class_id in sorted(targets.keys()):
        originales = len(set(clase_a_imagenes[class_id]))
        target = targets[class_id]
        a_generar = max(0, target - originales)
        
        if class_id < len(CLASES):
            nombre = CLASES[class_id]
        else:
            nombre = f"clase_{class_id}"
        
        print(f"   Clase {class_id} ({nombre}): {originales} → {target} (+{a_generar} augmentadas)")
    
    return targets

def procesar_clase_directamente(class_id, imagenes_originales, augmentations, target_imagenes):
    """Procesa una clase completa con target dinámico"""
    
    if class_id < len(CLASES):
        nombre_clase = CLASES[class_id]
    else:
        nombre_clase = f"clase_{class_id}"
    
    print(f"\n🔄 Procesando clase {class_id} ({nombre_clase})...")
    print(f"   Target: {target_imagenes} imágenes totales")
    
    todas_imagenes = []
    
    print(f"  📝 Agregando {len(imagenes_originales)} imágenes originales...")
    for img_path in imagenes_originales:
        label_path = TRAIN_LABELS / f"{img_path.stem}.txt"
        todas_imagenes.append(('original', img_path, label_path))
    
    imagenes_a_generar = target_imagenes - len(imagenes_originales)
    
    if imagenes_a_generar > 0:
        print(f"  🎨 Generando {imagenes_a_generar} imágenes augmentadas...")
        generadas = 0
        intentos = 0
        
        ratio = imagenes_a_generar / len(imagenes_originales)
        if ratio > 5:
            max_intentos = imagenes_a_generar * MAX_INTENTOS_POR_IMAGEN
        elif ratio > 3:
            max_intentos = imagenes_a_generar * 12
        else:
            max_intentos = imagenes_a_generar * 10
        
        print(f"  🎯 Intentos máximos: {max_intentos} (ratio: {ratio:.1f}x)")
        
        pbar = tqdm(total=imagenes_a_generar, desc=f"  Augmentation {nombre_clase}", leave=False)
        
        intentos_fallidos_consecutivos = 0
        MAX_FALLOS_CONSECUTIVOS = len(imagenes_originales) * 5
        
        while generadas < imagenes_a_generar and intentos < max_intentos:
            img_path = random.choice(imagenes_originales)
            label_path = TRAIN_LABELS / f"{img_path.stem}.txt"
            transform = random.choice(augmentations)
            
            aug_image, aug_bboxes, aug_labels = aplicar_augmentation(
                img_path, label_path, transform
            )
            
            if aug_image is not None:
                todas_imagenes.append(('augmented', aug_image, aug_bboxes, aug_labels, generadas))
                generadas += 1
                pbar.update(1)
                intentos_fallidos_consecutivos = 0
                
                if generadas % 50 == 0:
                    gc.collect()
            else:
                intentos_fallidos_consecutivos += 1
                
                if intentos_fallidos_consecutivos >= MAX_FALLOS_CONSECUTIVOS:
                    print(f"\n  ⚠️  Demasiados fallos consecutivos. Deteniendo en {generadas}/{imagenes_a_generar}")
                    break
            
            intentos += 1
        
        pbar.close()
        
        porcentaje = (generadas / imagenes_a_generar * 100) if imagenes_a_generar > 0 else 100
        if generadas < imagenes_a_generar:
            print(f"  ⚠️  Generadas {generadas}/{imagenes_a_generar} ({porcentaje:.1f}%) - {intentos} intentos")
        else:
            print(f"  ✅ Generadas {generadas}/{imagenes_a_generar} (100%) - {intentos} intentos")
    
    total_final = len(todas_imagenes)
    print(f"  💾 Guardando {total_final} imágenes en splits...")
    random.shuffle(todas_imagenes)
    
    n_total = len(todas_imagenes)
    n_train = int(n_total * TRAIN_SPLIT)
    n_valid = int(n_total * VALID_SPLIT)
    
    splits = {
        'train': todas_imagenes[:n_train],
        'valid': todas_imagenes[n_train:n_train + n_valid],
        'test': todas_imagenes[n_train + n_valid:]
    }
    
    for split_name, split_imgs in splits.items():
        for idx, item in enumerate(split_imgs):
            if item[0] == 'original':
                _, img_path, label_path = item
                nuevo_nombre = f"clase_{class_id}_{split_name}_{idx}{img_path.suffix}"
                nuevo_label = f"clase_{class_id}_{split_name}_{idx}.txt"
                
                shutil.copy(img_path, OUTPUT_DIR / split_name / 'images' / nuevo_nombre)
                
                bboxes_orig, labels_orig = leer_label_yolo(label_path)
                if len(bboxes_orig) > 0:
                    guardar_label_yolo(
                        OUTPUT_DIR / split_name / 'labels' / nuevo_label,
                        bboxes_orig,
                        labels_orig
                    )
            else:
                _, aug_image, aug_bboxes, aug_labels, _ = item
                nuevo_nombre = f"clase_{class_id}_{split_name}_aug_{idx}.jpg"
                nuevo_label = f"clase_{class_id}_{split_name}_aug_{idx}.txt"
                
                success = cv2.imwrite(
                    str(OUTPUT_DIR / split_name / 'images' / nuevo_nombre),
                    aug_image
                )
                
                if success and len(aug_bboxes) > 0:
                    guardar_label_yolo(
                        OUTPUT_DIR / split_name / 'labels' / nuevo_label,
                        aug_bboxes,
                        aug_labels
                    )
                    
                    verificar_bboxes, verificar_labels = leer_label_yolo(
                        OUTPUT_DIR / split_name / 'labels' / nuevo_label
                    )
                    
                    if len(verificar_bboxes) == 0:
                        (OUTPUT_DIR / split_name / 'images' / nuevo_nombre).unlink(missing_ok=True)
                        (OUTPUT_DIR / split_name / 'labels' / nuevo_label).unlink(missing_ok=True)
                else:
                    (OUTPUT_DIR / split_name / 'labels' / nuevo_label).unlink(missing_ok=True)
    
    del todas_imagenes
    gc.collect()
    
    print(f"  ✅ Clase {class_id} ({nombre_clase}) completada - Total: {total_final} imágenes")
    
    return total_final

def crear_yaml():
    """Crea el archivo data.yaml para YOLO"""
    clases_procesadas = set()
    for split in ['train', 'valid', 'test']:
        labels_dir = OUTPUT_DIR / split / 'labels'
        if labels_dir.exists():
            for label_file in labels_dir.glob('*.txt'):
                with open(label_file, 'r') as f:
                    for line in f:
                        parts = line.strip().split()
                        if len(parts) >= 5:
                            clases_procesadas.add(int(parts[0]))
    
    max_clase = max(clases_procesadas) if clases_procesadas else len(CLASES) - 1
    nombres_clases = []
    
    for i in range(max_clase + 1):
        if i < len(CLASES):
            nombres_clases.append(CLASES[i])
        else:
            nombres_clases.append(f"clase_{i}")
    
    yaml_content = f"""train: ./train/images
val: ./valid/images
test: ./test/images

nc: {len(nombres_clases)}
names: {nombres_clases}
"""
    
    with open(OUTPUT_DIR / 'data.yaml', 'w') as f:
        f.write(yaml_content)
    
    print(f"\n✅ Archivo data.yaml creado con {len(nombres_clases)} clases")

def validar_dataset():
    """Valida que cada imagen tenga su label correspondiente"""
    problemas = []
    
    for split in ['train', 'valid', 'test']:
        imgs_dir = OUTPUT_DIR / split / 'images'
        labels_dir = OUTPUT_DIR / split / 'labels'
        
        imagenes = list(imgs_dir.glob('*.[jp][pn]g')) + list(imgs_dir.glob('*.[JP][PN]G'))
        labels = list(labels_dir.glob('*.txt'))
        
        imagenes_sin_label = []
        labels_vacias = []
        
        for img_path in imagenes:
            label_path = labels_dir / f"{img_path.stem}.txt"
            
            if not label_path.exists():
                imagenes_sin_label.append(img_path.name)
            else:
                with open(label_path, 'r') as f:
                    content = f.read().strip()
                    if not content:
                        labels_vacias.append(label_path.name)
                        img_path.unlink()
                        label_path.unlink()
        
        labels_huerfanas = []
        for label_path in labels:
            img_extensions = ['.jpg', '.jpeg', '.png', '.JPG', '.JPEG', '.PNG']
            img_exists = any((imgs_dir / f"{label_path.stem}{ext}").exists() for ext in img_extensions)
            
            if not img_exists:
                labels_huerfanas.append(label_path.name)
                label_path.unlink()
        
        if imagenes_sin_label:
            problemas.append(f"  ⚠️  {split}: {len(imagenes_sin_label)} imágenes sin label (eliminadas)")
        
        if labels_vacias:
            problemas.append(f"  ⚠️  {split}: {len(labels_vacias)} labels vacías (eliminadas)")
        
        if labels_huerfanas:
            problemas.append(f"  ⚠️  {split}: {len(labels_huerfanas)} labels huérfanas (eliminadas)")
    
    if problemas:
        print("\n⚠️  Problemas encontrados y corregidos:")
        for problema in problemas:
            print(problema)
    else:
        print("  ✅ Dataset válido: todas las imágenes tienen sus labels")

def main():
    print("🚀 Iniciando proceso de balanceo y expansión del dataset")
    print("💾 MODO OPTIMIZADO - Balanceo inteligente por clase\n")
    
    clase_a_imagenes = analizar_dataset()
    targets = calcular_targets_balanceados(clase_a_imagenes)
    augmentations = crear_augmentations()
    
    print(f"\n🔄 Procesando {len(clase_a_imagenes)} clases...")
    resultados_finales = {}
    
    for class_id in sorted(clase_a_imagenes.keys()):
        imagenes_originales = list(set(clase_a_imagenes[class_id]))
        target = targets[class_id]
        
        total_generado = procesar_clase_directamente(
            class_id, imagenes_originales, augmentations, target
        )
        resultados_finales[class_id] = total_generado
        
        gc.collect()
    
    crear_yaml()
    
    print("\n🔍 Validando integridad del dataset...")
    validar_dataset()
    
    print("\n" + "="*70)
    print("🎉 ¡PROCESO COMPLETADO EXITOSAMENTE!")
    print("="*70)
    print(f"\n📂 Dataset balanceado guardado en: {OUTPUT_DIR}")
    
    for split in ['train', 'valid', 'test']:
        n_imgs = len(list((OUTPUT_DIR / split / 'images').glob('*')))
        n_labels = len(list((OUTPUT_DIR / split / 'labels').glob('*.txt')))
        print(f"  📊 {split.upper()}: {n_imgs} imágenes, {n_labels} labels")
    
    print(f"\n📈 Resultado final por clase:")
    for class_id in sorted(resultados_finales.keys()):
        originales = len(set(clase_a_imagenes[class_id]))
        final = resultados_finales[class_id]
        target = targets[class_id]
        porcentaje = (final / target * 100) if target > 0 else 100
        
        if class_id < len(CLASES):
            nombre = CLASES[class_id]
        else:
            nombre = f"clase_{class_id}"
        
        emoji = "✅" if porcentaje >= 95 else "🟡" if porcentaje >= 80 else "⚠️"
        print(f"  {emoji} Clase {class_id} ({nombre}): {originales} → {final}/{target} ({porcentaje:.1f}%)")
    
    print("\n💡 Próximos pasos:")
    print("   1. Revisa el reporte de validación arriba")
    print("   2. Usa data.yaml para entrenar con YOLO")
    print("   3. Comando: yolo train data=dataset_balanceado/data.yaml model=yolov8n.pt epochs=50")
    
    min_final = min(resultados_finales.values())
    max_final = max(resultados_finales.values())
    ratio_desbalance = max_final / min_final if min_final > 0 else float('inf')
    
    if ratio_desbalance > 2:
        print(f"\n⚠️  ADVERTENCIA: Desbalance detectado (ratio {ratio_desbalance:.1f}x)")
        print(f"    Clase más pequeña: {min_final} imágenes")
        print(f"    Clase más grande: {max_final} imágenes")

if __name__ == "__main__":
    main()